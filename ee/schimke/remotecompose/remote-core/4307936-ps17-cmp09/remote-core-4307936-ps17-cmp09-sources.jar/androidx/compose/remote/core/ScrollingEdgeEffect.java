/*
 * Copyright 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.compose.remote.core;

import static androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP;

import androidx.annotation.RestrictTo;
import androidx.compose.remote.core.operations.layout.Component;

import org.jspecify.annotations.NonNull;

/** Represents a scrolling edge effect (glow, stretch...) */
@RestrictTo(LIBRARY_GROUP)
public interface ScrollingEdgeEffect {

    int TOP = 0;
    int BOTTOM = 1;
    int LEFT = 2;
    int RIGHT = 3;
    int PRE_DRAW = 0;
    int POST_DRAW = 1;

    /** Reset the effect */
    void reset();

    /**
     * Apply a pull the effect
     *
     * @param value
     * @param distance
     */
    void pull(float value, float distance);

    /** Release the pull */
    void release();

    /**
     * Set the size of the edge effect
     *
     * @param width
     * @param height
     */
    void setSize(float width, float height);

    /**
     * Apply the effect
     *
     * @param context
     * @param component
     * @param contentDimension
     * @param phase 0 == pre-draw 1 == post-draw
     */
    void apply(
            @NonNull PaintContext context,
            @NonNull Component component,
            float contentDimension,
            int phase);
}
