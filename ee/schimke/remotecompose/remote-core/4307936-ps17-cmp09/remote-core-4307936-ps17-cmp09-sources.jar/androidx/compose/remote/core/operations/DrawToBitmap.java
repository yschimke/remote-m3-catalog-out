/*
 * Copyright (C) 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.compose.remote.core.operations;

import androidx.annotation.RestrictTo;
import androidx.compose.remote.core.Operation;
import androidx.compose.remote.core.Operations;
import androidx.compose.remote.core.PaintContext;
import androidx.compose.remote.core.PaintOperation;
import androidx.compose.remote.core.WireBuffer;
import androidx.compose.remote.core.documentation.DocumentationBuilder;
import androidx.compose.remote.core.documentation.DocumentedOperation;
import androidx.compose.remote.core.serialize.MapSerializer;
import androidx.compose.remote.core.serialize.Serializable;

import org.jspecify.annotations.NonNull;

import java.util.List;

/** Draw to a bitmap. This command redirects drawing to a bitmap. */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public class DrawToBitmap extends PaintOperation implements Serializable {
    private static final int OP_CODE = Operations.DRAW_TO_BITMAP;
    private static final String CLASS_NAME = "DrawToBitmap";
    private final int mBitmapId;
    private final int mMode;
    private final int mColor;

    public static final int MODE_NO_INITIALIZE = 1;
    public static final int MODE_COMPONENT_ID = 2;

    public DrawToBitmap(int bitmapId, int mode, int color) {
        mBitmapId = bitmapId;
        mMode = mode;
        mColor = color;
    }

    @Override
    public void write(@NonNull WireBuffer buffer) {
        apply(buffer, mBitmapId, mMode, mColor);
    }

    /**
     * Read this operation and add it to the list of operations
     *
     * @param buffer the buffer to read
     * @param operations the list of operations that will be added to
     */
    public static void read(@NonNull WireBuffer buffer, @NonNull List<Operation> operations) {
        int bitmapId = buffer.readId();
        int mode = buffer.readInt();
        int color = buffer.readInt();
        operations.add(new DrawToBitmap(bitmapId, mode, color));
    }

    @NonNull
    @Override
    public String toString() {
        return "DrawToBitmap";
    }

    /**
     * The name of the class
     *
     * @return the name
     */
    @NonNull
    public static String name() {
        return CLASS_NAME;
    }

    /**
     * The OP_CODE for this command
     *
     * @return the opcode
     */
    public static int id() {
        return OP_CODE;
    }

    /**
     * add a matrix restore operation to the buffer
     *
     * @param buffer the buffer to add to
     * @param bitmapId the id of the bitmap to draw to
     * @param mode
     * @param color
     */
    public static void apply(@NonNull WireBuffer buffer, int bitmapId, int mode, int color) {
        buffer.start(OP_CODE);
        buffer.writeInt(bitmapId);
        buffer.writeInt(mode);
        buffer.writeInt(color);
    }

    /**
     * Populate the documentation with a description of this operation
     *
     * @param doc to append the description to.
     */
    public static void documentation(@NonNull DocumentationBuilder doc) {
        doc.operation("Canvas Operations", OP_CODE, CLASS_NAME)
                .addedVersion(7)
                .description("Draw to a bitmap")
                .field(
                        DocumentedOperation.INT,
                        "bitmapId",
                        "The bitmap to draw to or 0 to draw to the canvas")
                .field(DocumentedOperation.INT, "mode", "Flags to support configuration of bitmap")
                .field(DocumentedOperation.INT, "color", "set the initial of the bitmap");
    }

    @Override
    public void paint(@NonNull PaintContext context) {
        int id = getId(mBitmapId, context);
        int mode = mMode;
        int color = mColor;
        if (id == 0) {
            if (context.hasActiveOffscreenTarget()) {
                if (context.popOffscreenTarget()) {
                    context.restore();
                }
                int parentBitmapId = context.getOffscreenBitmapId();
                if (parentBitmapId != 0) {
                    BitmapData.resumeOffscreenTargetCanvas(context, parentBitmapId);
                    return;
                }
            }
            context.drawToBitmap(0, mode, color);
            return;
        }
        boolean isComponentOffscreen = (mode & MODE_COMPONENT_ID) != 0;
        androidx.compose.remote.core.operations.layout.Component target =
                context.getContext().mLastComponent;
        if (isComponentOffscreen) {
            mode &= ~MODE_COMPONENT_ID;
            int compId = color;
            if (compId > 0) {
                int resolved = context.getContext().getInteger(compId);
                if (resolved != 0) {
                    compId = resolved;
                } else {
                    float fVal = context.getContext().getFloat(compId);
                    if (!Float.isNaN(fVal) && fVal != 0f) {
                        compId = (int) fVal;
                    }
                }
            }
            if (context.getContext().getDocument() != null) {
                androidx.compose.remote.core.operations.layout.Component found =
                        context.getContext().getDocument().getComponent(compId);
                if (found != null) {
                    target = found;
                }
            }
            color = 0;
        }
        Object obj = context.getContext().getObject(id);
        if (obj instanceof BitmapData) {
            BitmapData bd = (BitmapData) obj;
            if (bd.getEncoding() == BitmapData.ENCODING_COMPONENT_OFFSCREEN_BUFFER) {
                boolean hasClip = false;
                androidx.compose.remote.core.operations.layout.Component prevComp =
                        context.getOffscreenComponent();
                context.setOffscreenComponent(target);
                bd.ensureOffscreenBitmap(context.getContext());
                context.drawToBitmap(id, mode, color);
                if (bd.getWidth() > 0 && bd.getHeight() > 0) {
                    context.save();
                    context.clipRect(0f, 0f, bd.getWidth(), bd.getHeight());
                    hasClip = true;
                }
                context.setOffscreenComponent(prevComp);
                context.pushOffscreenTarget(target, id, hasClip);
                return;
            }
        }
        if (isComponentOffscreen) {
            context.pushOffscreenTarget(target, id, false);
        }
        context.drawToBitmap(id, mode, color);
    }

    @Override
    public void serialize(@NonNull MapSerializer serializer) {
        serializer
                .addType(CLASS_NAME)
                .add("bitmapId", mBitmapId)
                .add("mode", mMode)
                .add("color", mColor);
    }
}
