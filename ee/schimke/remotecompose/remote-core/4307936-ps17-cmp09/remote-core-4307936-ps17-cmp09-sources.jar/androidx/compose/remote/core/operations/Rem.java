/*
 * Copyright (C) 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.compose.remote.core.operations;

import static androidx.compose.remote.core.documentation.DocumentedOperation.UTF8;

import androidx.annotation.RestrictTo;
import androidx.compose.remote.core.Limits;
import androidx.compose.remote.core.Operation;
import androidx.compose.remote.core.Operations;
import androidx.compose.remote.core.RemoteContext;
import androidx.compose.remote.core.SerializableToString;
import androidx.compose.remote.core.WireBuffer;
import androidx.compose.remote.core.documentation.DocumentationBuilder;
import androidx.compose.remote.core.operations.utilities.StringSerializer;
import androidx.compose.remote.core.serialize.MapSerializer;
import androidx.compose.remote.core.serialize.Serializable;

import org.jspecify.annotations.NonNull;

import java.util.List;

/** this is an in code comment block used in debugging and IDE support */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public class Rem extends Operation implements SerializableToString, Serializable {
    private static final int OP_CODE = Operations.REM;
    private static final String CLASS_NAME = "Rem";
    @NonNull public String mText;

    public Rem(@NonNull String text) {
        this.mText = text;
    }

    /**
     * Copy the data from another text data
     *
     * @param from source to copy from
     */
    public void update(@NonNull Rem from) {
        mText = from.mText;
    }

    @Override
    public void write(@NonNull WireBuffer buffer) {
        apply(buffer, mText);
    }

    @NonNull
    @Override
    public String toString() {
        return "Rem \"" + Utils.trimString(mText, 10) + "\"";
    }

    /**
     * The name of the class
     *
     * @return the name
     */
    @NonNull
    public static String name() {
        return CLASS_NAME;
    }

    /**
     * The OP_CODE for this command
     *
     * @return the opcode
     */
    public static int id() {
        return OP_CODE;
    }

    /**
     * add a Rem data operation
     *
     * @param buffer buffer to add to
     * @param text the data to encode
     */
    public static void apply(@NonNull WireBuffer buffer, @NonNull String text) {
        buffer.start(OP_CODE);
        buffer.writeUTF8(text);
    }

    /**
     * Read this operation and add it to the list of operations
     *
     * @param buffer the buffer to read
     * @param operations the list of operations that will be added to
     */
    public static void read(@NonNull WireBuffer buffer, @NonNull List<Operation> operations) {
        String text = buffer.readUTF8(Limits.MAX_STRING_SIZE);
        operations.add(new Rem(text));
    }

    /**
     * Populate the documentation with a description of this operation
     *
     * @param doc to append the description to.
     */
    public static void documentation(@NonNull DocumentationBuilder doc) {
        doc.operation("Document Protocol Operations", OP_CODE, CLASS_NAME)
                .addedVersion(7)
                .description("Embed a remark or comment string in the document")
                .field(UTF8, "text", "The comment string");
    }

    @Override
    public void apply(@NonNull RemoteContext context) {}

    @NonNull
    @Override
    public String deepToString(@NonNull String indent) {
        return indent + toString();
    }

    @Override
    public void serializeToString(int indent, @NonNull StringSerializer serializer) {
        serializer.append(indent, getSerializedName() + " = \"" + mText + "\"");
    }

    @NonNull
    private String getSerializedName() {
        return "DATA_TEXT";
    }

    @Override
    public void serialize(@NonNull MapSerializer serializer) {
        serializer.addType(CLASS_NAME).add("text", mText);
    }
}
