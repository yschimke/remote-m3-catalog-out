/*
 * Copyright (C) 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.compose.remote.core.operations.layout.managers;

import static androidx.compose.remote.core.documentation.DocumentedOperation.FLOAT;
import static androidx.compose.remote.core.documentation.DocumentedOperation.INT;

import androidx.annotation.RestrictTo;
import androidx.compose.remote.core.CoreDocument;
import androidx.compose.remote.core.Operation;
import androidx.compose.remote.core.Operations;
import androidx.compose.remote.core.PaintContext;
import androidx.compose.remote.core.RemoteContext;
import androidx.compose.remote.core.WireBuffer;
import androidx.compose.remote.core.documentation.DocumentationBuilder;
import androidx.compose.remote.core.operations.layout.Component;
import androidx.compose.remote.core.operations.layout.LayoutComponent;
import androidx.compose.remote.core.operations.layout.measure.ComponentMeasure;
import androidx.compose.remote.core.operations.layout.measure.MeasurePass;
import androidx.compose.remote.core.operations.layout.measure.Size;
import androidx.compose.remote.core.operations.layout.modifiers.DimensionInModifierOperation;
import androidx.compose.remote.core.operations.layout.modifiers.ScrollModifierOperation;
import androidx.compose.remote.core.operations.layout.utils.DebugLog;
import androidx.compose.remote.core.serialize.MapSerializer;

import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

import java.util.List;

/**
 * Simple Column layout implementation - also supports weight and horizontal/vertical positioning
 */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public class ColumnLayout extends LayoutManager {
    public static final int START = 1;
    public static final int CENTER = 2;
    public static final int END = 3;
    public static final int TOP = 4;
    public static final int BOTTOM = 5;
    public static final int SPACE_BETWEEN = 6;
    public static final int SPACE_EVENLY = 7;
    public static final int SPACE_AROUND = 8;

    int mHorizontalPositioning;
    int mVerticalPositioning;
    float mSpacedBy = 0f;

    private static final boolean DIRECT_WEIGHT_CALCULATION = true;

    public ColumnLayout(
            @Nullable Component parent,
            int componentId,
            int animationId,
            float x,
            float y,
            float width,
            float height,
            int horizontalPositioning,
            int verticalPositioning,
            float spacedBy) {
        super(parent, componentId, animationId, x, y, width, height);
        mHorizontalPositioning = horizontalPositioning;
        mVerticalPositioning = verticalPositioning;
        mSpacedBy = spacedBy;
    }

    public ColumnLayout(
            @Nullable Component parent,
            int componentId,
            int animationId,
            int horizontalPositioning,
            int verticalPositioning,
            float spacedBy) {
        this(
                parent,
                componentId,
                animationId,
                0,
                0,
                0,
                0,
                horizontalPositioning,
                verticalPositioning,
                spacedBy);
    }

    @NonNull
    @Override
    public String toString() {
        return getSerializedName()
                + " ["
                + mComponentId
                + ":"
                + mAnimationId
                + "] ("
                + mX
                + ", "
                + mY
                + " - "
                + mWidth
                + " x "
                + mHeight
                + ") "
                + mVisibility;
    }

    @NonNull
    @Override
    protected String getSerializedName() {
        return "COLUMN";
    }

    @Override
    public boolean isInVerticalFill() {
        return super.isInVerticalFill() || childrenHaveVerticalWeights();
    }

    @Override
    public void computeWrapSize(
            @NonNull PaintContext context,
            float minWidth,
            float maxWidth,
            float minHeight,
            float maxHeight,
            boolean horizontalWrap,
            boolean verticalWrap,
            @NonNull MeasurePass measure,
            @NonNull Size size) {
        DebugLog.s(() -> "COMPUTE WRAP SIZE in " + this + " (" + mComponentId + ")");
        int visibleChildrens = 0;
        float currentMaxHeight = maxHeight;

        float totalWeights = 0f;
        boolean hasWeights = false;
        for (Component child : mChildrenComponents) {
            ComponentMeasure childMeasure = measure.get(child);
            if (childMeasure.isGone()) {
                continue;
            }
            if (child instanceof LayoutComponent
                    && ((LayoutComponent) child).getHeightModifier().hasWeight()) {
                hasWeights = true;
                totalWeights += ((LayoutComponent) child).getHeightModifier().getValue();
            }
        }

        if (hasWeights) {
            // we have to measure all children first that do not have weight
            for (Component c : mChildrenComponents) {
                if (c instanceof LayoutComponent
                        && ((LayoutComponent) c).getHeightModifier().hasWeight()) {
                    continue;
                }
                c.measure(context, 0f, maxWidth, 0f, currentMaxHeight, measure);
                ComponentMeasure m = measure.get(c);
                if (!m.isGone()) {
                    size.setWidth(Math.max(size.getWidth(), m.getW()));
                    size.setHeight(size.getHeight() + m.getH());
                    visibleChildrens++;
                    currentMaxHeight -= m.getH();
                }
            }
            // Then we can measure the children with weight
            for (Component c : mChildrenComponents) {
                if (!(c instanceof LayoutComponent
                        && ((LayoutComponent) c).getHeightModifier().hasWeight())) {
                    continue;
                }
                float childWeight = ((LayoutComponent) c).getHeightModifier().getValue();
                float childMinHeight = (childWeight * currentMaxHeight) / totalWeights;
                float childMaxHeight = childMinHeight;
                c.measure(context, 0f, maxWidth, childMinHeight, childMaxHeight, measure);
                ComponentMeasure m = measure.get(c);
                if (!m.isGone()) {
                    size.setWidth(Math.max(size.getWidth(), m.getW()));
                    size.setHeight(size.getHeight() + m.getH());
                    visibleChildrens++;
                }
            }
        } else {
            for (Component c : mChildrenComponents) {
                c.measure(context, 0f, maxWidth, 0f, currentMaxHeight, measure);
                ComponentMeasure m = measure.get(c);
                if (!m.isGone()) {
                    size.setWidth(Math.max(size.getWidth(), m.getW()));
                    size.setHeight(size.getHeight() + m.getH());
                    visibleChildrens++;
                    currentMaxHeight -= m.getH();
                }
            }
        }
        if (!mChildrenComponents.isEmpty()) {
            float spacedBy = mSpacedBy;
            if (context.getDensityBehavior() == CoreDocument.DENSITY_BEHAVIOR_DP) {
                spacedBy *= context.getDensity();
            }
            size.setHeight(size.getHeight() + (spacedBy * (visibleChildrens - 1)));
        }
        DebugLog.e();
    }

    @Override
    public void computeSize(
            @NonNull PaintContext context,
            float minWidth,
            float maxWidth,
            float minHeight,
            float maxHeight,
            @NonNull MeasurePass measure) {
        DebugLog.s(() -> "COMPUTE SIZE in " + this + " (" + mComponentId + ")");

        // Check for weights
        float totalHeightsNoWeights = 0f;
        float totalWeights = 0f;
        boolean hasWeights = false;
        float maxh = maxHeight;
        if (DIRECT_WEIGHT_CALCULATION) {
            for (Component child : mChildrenComponents) {
                ComponentMeasure childMeasure = measure.get(child);
                if (childMeasure.isGone()) {
                    continue;
                }
                if (child instanceof LayoutComponent
                        && ((LayoutComponent) child).getHeightModifier().hasWeight()) {
                    hasWeights = true;
                    totalWeights += ((LayoutComponent) child).getHeightModifier().getValue();
                } else {
                    child.measure(context, minWidth, maxWidth, minHeight, maxh, measure);
                    ComponentMeasure m = measure.get(child);
                    maxh -= m.getH();
                    totalHeightsNoWeights += m.getH();
                }
            }
        }

        if (hasWeights && DIRECT_WEIGHT_CALCULATION) {
            float minh = minHeight;
            maxh = maxHeight;
            for (Component child : mChildrenComponents) {
                if (child instanceof LayoutComponent
                        && ((LayoutComponent) child).getHeightModifier().hasWeight()
                        && !child.isGone()) {
                    float weight = ((LayoutComponent) child).getHeightModifier().getValue();
                    float childHeight = (maxHeight - totalHeightsNoWeights) * weight / totalWeights;
                    child.measure(context, minWidth, maxWidth, childHeight, childHeight, measure);
                } else {
                    child.measure(context, minWidth, maxWidth, minh, maxh, measure);
                }
                ComponentMeasure m = measure.get(child);
                if (!m.isGone()) {
                    maxh -= m.getH();
                }
            }
        } else {
            float mh = maxHeight;
            for (Component child : mChildrenComponents) {
                child.measure(context, minWidth, maxWidth, minHeight, mh, measure);
                ComponentMeasure m = measure.get(child);
                if (!m.isGone()) {
                    mh -= m.getH();
                }
            }
        }
        DebugLog.e();
    }

    @Override
    public float minIntrinsicHeight(@NonNull RemoteContext context) {
        float height = computeModifierDefinedHeight(context, true);
        float componentHeights = 0f;
        for (Component c : mChildrenComponents) {
            componentHeights += c.minIntrinsicHeight(context);
        }
        return Math.max(height, componentHeights);
    }

    @Override
    public void internalLayoutMeasure(@NonNull PaintContext context, @NonNull MeasurePass measure) {
        ComponentMeasure selfMeasure = measure.get(this);
        DebugLog.s(
                () ->
                        "INTERNAL LAYOUT "
                                + this
                                + " ("
                                + mComponentId
                                + ") children: "
                                + mChildrenComponents.size()
                                + " size ("
                                + selfMeasure.getW()
                                + " x "
                                + selfMeasure.getH()
                                + ")");
        if (mChildrenComponents.isEmpty()) {
            DebugLog.e();
            return;
        }
        float selfWidth = selfMeasure.getW() - mPaddingLeft - mPaddingRight;
        float selfHeight = selfMeasure.getH() - mPaddingTop - mPaddingBottom;
        float childrenWidth = 0f;
        float childrenHeight = 0f;

        if (mComponentModifiers.hasHorizontalScroll()) {
            selfWidth =
                    mComponentModifiers.getHorizontalScrollDimension()
                            - mPaddingLeft
                            - mPaddingRight;
        }
        if (mComponentModifiers.hasVerticalScroll()) {
            selfHeight =
                    mComponentModifiers.getVerticalScrollDimension() - mPaddingTop - mPaddingBottom;
        }
        boolean checkWeights = true;
        while (checkWeights) {
            checkWeights = false;
            childrenWidth = 0f;
            childrenHeight = 0f;
            boolean hasWeights = false;
            float totalWeights = 0f;
            for (Component child : mChildrenComponents) {
                ComponentMeasure childMeasure = measure.get(child);
                if (childMeasure.isGone()) {
                    continue;
                }
                if (child instanceof LayoutComponent
                        && ((LayoutComponent) child).getHeightModifier().hasWeight()) {
                    hasWeights = true;
                    totalWeights += ((LayoutComponent) child).getHeightModifier().getValue();
                } else {
                    childrenHeight += childMeasure.getH();
                }
            }
            if (hasWeights) {
                float availableSpace = selfHeight - childrenHeight;
                for (Component child : mChildrenComponents) {
                    if (child instanceof LayoutComponent
                            && ((LayoutComponent) child).getHeightModifier().hasWeight()) {
                        ComponentMeasure childMeasure = measure.get(child);
                        if (childMeasure.isGone()) {
                            continue;
                        }
                        float weight = ((LayoutComponent) child).getHeightModifier().getValue();
                        float childHeight = (weight * availableSpace) / totalWeights;
                        DimensionInModifierOperation heightInConstraints =
                                ((LayoutComponent) child).getHeightModifier().getHeightIn();
                        if (heightInConstraints != null) {
                            float min = heightInConstraints.getMin();
                            float max = heightInConstraints.getMax();
                            if (min != -1) {
                                childHeight = Math.max(min, childHeight);
                            }
                            if (max != -1) {
                                childHeight = Math.min(max, childHeight);
                            }
                        }
                        childMeasure.setH(childHeight);
                        child.measure(
                                context,
                                childMeasure.getW(),
                                childMeasure.getW(),
                                childMeasure.getH(),
                                childMeasure.getH(),
                                measure);
                    }
                }
            }

            if (applyVisibility(selfWidth, selfHeight, measure) && hasWeights) {
                checkWeights = true;
            }
        }

        childrenHeight = 0f;
        int visibleChildrens = 0;
        for (Component child : mChildrenComponents) {
            ComponentMeasure childMeasure = measure.get(child);
            if (childMeasure.isGone()) {
                continue;
            }
            childrenWidth = Math.max(childrenWidth, childMeasure.getW());
            childrenHeight += childMeasure.getH();
            visibleChildrens++;
        }
        float spacedBy = mSpacedBy;
        if (context.getDensityBehavior() == CoreDocument.DENSITY_BEHAVIOR_DP) {
            spacedBy *= context.getDensity();
        }
        childrenHeight += spacedBy * (visibleChildrens - 1);

        float tx = 0f;
        float ty = 0f;

        float verticalGap = 0f;
        float total = 0f;
        switch (mVerticalPositioning) {
            case TOP:
                ty = 0f;
                break;
            case CENTER:
                ty = (selfHeight - childrenHeight) / 2f;
                break;
            case BOTTOM:
                ty = selfHeight - childrenHeight;
                break;
            case SPACE_BETWEEN:
                for (Component child : mChildrenComponents) {
                    ComponentMeasure childMeasure = measure.get(child);
                    if (childMeasure.isGone()) {
                        continue;
                    }
                    total += childMeasure.getH();
                }
                if (visibleChildrens > 1) {
                    verticalGap = (selfHeight - total) / (visibleChildrens - 1);
                } else {
                    // we center the element
                    ty = (selfHeight - childrenHeight) / 2f;
                }
                break;
            case SPACE_EVENLY:
                for (Component child : mChildrenComponents) {
                    ComponentMeasure childMeasure = measure.get(child);
                    if (childMeasure.isGone()) {
                        continue;
                    }
                    total += childMeasure.getH();
                }
                verticalGap = (selfHeight - total) / (visibleChildrens + 1);
                ty = verticalGap;
                break;
            case SPACE_AROUND:
                for (Component child : mChildrenComponents) {
                    ComponentMeasure childMeasure = measure.get(child);
                    if (childMeasure.isGone()) {
                        continue;
                    }
                    total += childMeasure.getH();
                }
                verticalGap = (selfHeight - total) / visibleChildrens;
                ty = verticalGap / 2f;
                break;
        }

        for (Component child : mChildrenComponents) {
            ComponentMeasure childMeasure = measure.get(child);
            switch (mHorizontalPositioning) {
                case START:
                    tx = 0f;
                    break;
                case CENTER:
                    tx = (selfWidth - childMeasure.getW()) / 2f;
                    break;
                case END:
                    tx = selfWidth - childMeasure.getW();
                    break;
            }
            childMeasure.setX(tx);
            childMeasure.setY(ty);
            if (childMeasure.isGone()) {
                continue;
            }
            ty += childMeasure.getH();
            if (mVerticalPositioning == SPACE_BETWEEN
                    || mVerticalPositioning == SPACE_AROUND
                    || mVerticalPositioning == SPACE_EVENLY) {
                ty += verticalGap;
            }
            ty += spacedBy;
        }
        DebugLog.e();
    }

    @Override
    public void getLocationInWindow(
            @NonNull RemoteContext context, float @NonNull [] value, boolean forSelf) {
        super.getLocationInWindow(context, value, forSelf);
        if (context.getTouchVersion() != LayoutManager.FIX_TOUCH_EVENT) {
            if (!forSelf && mVerticalScrollDelegate instanceof ScrollModifierOperation) {
                ScrollModifierOperation smo = (ScrollModifierOperation) mVerticalScrollDelegate;

                value[1] += smo.getScrollY();
            }
        }
    }

    /**
     * The name of the class
     *
     * @return the name
     */
    @NonNull
    public static String name() {
        return "ColumnLayout";
    }

    /**
     * The OP_CODE for this command
     *
     * @return the opcode
     */
    public static int id() {
        return Operations.LAYOUT_COLUMN;
    }

    /**
     * Write the operation to the buffer
     *
     * @param buffer wire buffer
     * @param componentId component id
     * @param animationId animation id (-1 if not set)
     * @param horizontalPositioning horizontal positioning rules
     * @param verticalPositioning vertical positioning rules
     * @param spacedBy spaced by value
     */
    public static void apply(
            @NonNull WireBuffer buffer,
            int componentId,
            int animationId,
            int horizontalPositioning,
            int verticalPositioning,
            float spacedBy) {
        buffer.start(id());
        buffer.writeInt(componentId);
        buffer.writeInt(animationId);
        buffer.writeInt(horizontalPositioning);
        buffer.writeInt(verticalPositioning);
        buffer.writeFloat(spacedBy);
    }

    /**
     * Read this operation and add it to the list of operations
     *
     * @param buffer the buffer to read
     * @param operations the list of operations that will be added to
     */
    public static void read(@NonNull WireBuffer buffer, @NonNull List<Operation> operations) {
        int componentId = buffer.declareId();
        int animationId = buffer.declareId();
        int horizontalPositioning = buffer.readInt();
        int verticalPositioning = buffer.readInt();
        float spacedBy = buffer.readFloat();
        operations.add(
                new ColumnLayout(
                        null,
                        componentId,
                        animationId,
                        horizontalPositioning,
                        verticalPositioning,
                        spacedBy));
    }

    /**
     * Populate the documentation with a description of this operation
     *
     * @param doc to append the description to.
     */
    public static void documentation(@NonNull DocumentationBuilder doc) {
        doc.operation("Layout Managers", id(), name())
                .additionalDocumentation("column")
                .description(
                        "Column layout implementation, positioning components one"
                                + " after the other vertically.\n\n"
                                + "It supports weight and horizontal/vertical positioning.")
                .examplesDimension(100, 400)
                .exampleImage("Top", "layout-ColumnLayout-start-top.png")
                .exampleImage("Center", "layout-ColumnLayout-start-center.png")
                .exampleImage("Bottom", "layout-ColumnLayout-start-bottom.png")
                .exampleImage("SpaceEvenly", "layout-ColumnLayout-start-space-evenly.png")
                .exampleImage("SpaceAround", "layout-ColumnLayout-start-space-around.png")
                .exampleImage("SpaceBetween", "layout-ColumnLayout-start-space-between.png")
                .field(INT, "componentId", "Unique ID for this component")
                .field(INT, "animationId", "ID used to match components for animation purposes")
                .field(INT, "horizontalPositioning", "Horizontal positioning value")
                .possibleValues("START", START)
                .possibleValues("CENTER", CENTER)
                .possibleValues("END", END)
                .field(INT, "verticalPositioning", "Vertical positioning value")
                .possibleValues("TOP", TOP)
                .possibleValues("CENTER", CENTER)
                .possibleValues("BOTTOM", BOTTOM)
                .possibleValues("SPACE_BETWEEN", SPACE_BETWEEN)
                .possibleValues("SPACE_EVENLY", SPACE_EVENLY)
                .possibleValues("SPACE_AROUND", SPACE_AROUND)
                .field(FLOAT, "spacedBy", "Horizontal spacing between components");
    }

    @Override
    public float maxIntrinsicHeight(@Nullable RemoteContext context) {
        float height = computeModifierDefinedHeight(context);
        float childrenHeight = 0f;
        for (Component c : mChildrenComponents) {
            childrenHeight += c.maxIntrinsicHeight(context);
        }
        return Math.max(height, childrenHeight);
    }

    @Override
    public void write(@NonNull WireBuffer buffer) {
        apply(
                buffer,
                mComponentId,
                mAnimationId,
                mHorizontalPositioning,
                mVerticalPositioning,
                mSpacedBy);
    }

    @Override
    public void serialize(@NonNull MapSerializer serializer) {
        super.serialize(serializer);
        serializer.add("verticalPositioning", getPositioningString(mVerticalPositioning));
        serializer.add("horizontalPositioning", getPositioningString(mHorizontalPositioning));
        serializer.add("spacedBy", mSpacedBy);
    }

    private String getPositioningString(int pos) {
        switch (pos) {
            case START:
                return "START";
            case CENTER:
                return "CENTER";
            case END:
                return "END";
            case TOP:
                return "TOP";
            case BOTTOM:
                return "BOTTOM";
            case SPACE_BETWEEN:
                return "SPACE_BETWEEN";
            case SPACE_EVENLY:
                return "SPACE_EVENLY";
            case SPACE_AROUND:
                return "SPACE_AROUND";
            default:
                return "NONE";
        }
    }
}
