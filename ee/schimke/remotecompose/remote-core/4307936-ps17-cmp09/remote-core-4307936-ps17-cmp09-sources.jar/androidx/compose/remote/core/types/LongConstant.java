/*
 * Copyright (C) 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.compose.remote.core.types;

import static androidx.compose.remote.core.documentation.DocumentedOperation.LONG;

import androidx.annotation.RestrictTo;
import androidx.compose.remote.core.Operation;
import androidx.compose.remote.core.Operations;
import androidx.compose.remote.core.RemoteContext;
import androidx.compose.remote.core.VariableProvider;
import androidx.compose.remote.core.WireBuffer;
import androidx.compose.remote.core.documentation.DocumentationBuilder;
import androidx.compose.remote.core.documentation.DocumentedOperation;
import androidx.compose.remote.core.operations.ComponentData;
import androidx.compose.remote.core.serialize.MapSerializer;
import androidx.compose.remote.core.serialize.Serializable;

import org.jspecify.annotations.NonNull;

import java.util.List;

/** Used to represent a long */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public class LongConstant extends Operation
        implements Serializable, VariableProvider, ComponentData {
    private static final String CLASS_NAME = "LongConstant";
    private static final int OP_CODE = Operations.DATA_LONG;
    private long mValue;
    public int mId;

    @Override
    public int getId() {
        return mId;
    }

    @Override
    public void setId(int id) {
        mId = id;
    }

    /**
     * @param id the id of the constant
     * @param value the value of the constant
     */
    public LongConstant(int id, long value) {
        mId = id;
        mValue = value;
    }

    /**
     * Copy the value from another longConstant
     *
     * @param from the constant to copy from
     */
    public void update(@NonNull LongConstant from) {
        mValue = from.mValue;
    }

    /**
     * Get the value of the long constant
     *
     * @return the value of the long
     */
    public long getValue() {
        return mValue;
    }

    /**
     * Set the value of the long constant
     *
     * @param value the value to set it to
     */
    public void setValue(long value) {
        mValue = value;
    }

    @Override
    public void write(@NonNull WireBuffer buffer) {
        apply(buffer, mId, mValue);
    }

    @Override
    public void apply(@NonNull RemoteContext context) {
        context.putObject(mId, this);
    }

    @NonNull
    @Override
    public String deepToString(@NonNull String indent) {
        return toString();
    }

    @NonNull
    @Override
    public String toString() {
        return "LongConstant[" + mId + "] = " + mValue + "";
    }

    /**
     * Writes out the operation to the buffer
     *
     * @param buffer
     * @param id
     * @param value
     */
    public static void apply(@NonNull WireBuffer buffer, int id, long value) {
        buffer.start(OP_CODE);
        buffer.writeInt(id);
        buffer.writeLong(value);
    }

    /**
     * Read this operation and add it to the list of operations
     *
     * @param buffer the buffer to read
     * @param operations the list of operations that will be added to
     */
    public static void read(@NonNull WireBuffer buffer, @NonNull List<Operation> operations) {
        int id = buffer.declareId();
        long value = buffer.readLongNanId();
        operations.add(new LongConstant(id, value));
    }

    /**
     * Populate the documentation with a description of this operation
     *
     * @param doc to append the description to.
     */
    public static void documentation(@NonNull DocumentationBuilder doc) {
        doc.operation("Data Operations", OP_CODE, "LongConstant")
                .description("A long and its associated id")
                .field(DocumentedOperation.INT, "id", "id of the Long constant")
                .field(LONG, "value", "The long Value");
    }

    @Override
    public void serialize(@NonNull MapSerializer serializer) {
        serializer.addType(CLASS_NAME).add("id", mId).add("value", mValue);
    }
}
