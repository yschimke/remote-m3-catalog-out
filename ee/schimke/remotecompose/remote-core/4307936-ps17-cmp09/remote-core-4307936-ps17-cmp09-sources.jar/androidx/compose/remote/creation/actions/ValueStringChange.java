/*
 * Copyright (C) 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.compose.remote.creation.actions;

import androidx.annotation.RestrictTo;
import androidx.compose.remote.creation.RemoteComposeWriter;

import org.jspecify.annotations.NonNull;

@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public class ValueStringChange implements Action {

    int mValueId = -1;
    @NonNull
    String mValue = "";

    int mValueStringId = -1;
    public ValueStringChange(int id, @NonNull String value) {
        mValueId = id;
        mValue = value;
    }

    public ValueStringChange(int id, int stringId) {
        mValueId = id;
        mValueStringId = stringId;
    }

    @Override
    public void write(@NonNull RemoteComposeWriter writer) {
        if (mValueStringId != -1) {
            writer.addValueStringChangeActionOperation(mValueId, mValueStringId);
        } else {
            int newValueId = writer.addText(mValue);
            writer.addValueStringChangeActionOperation(mValueId, newValueId);
        }
    }
}
