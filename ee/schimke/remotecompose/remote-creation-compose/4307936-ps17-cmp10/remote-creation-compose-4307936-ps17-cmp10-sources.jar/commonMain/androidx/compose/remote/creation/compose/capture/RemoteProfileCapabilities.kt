/*
 * Copyright 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

@file:Suppress("PrimitiveInCollection") // Profile.supportedOperations

package androidx.compose.remote.creation.compose.capture

import androidx.compose.remote.creation.compose.layout.RemoteComposable
import androidx.compose.remote.creation.compose.modifier.onTouchCancel
import androidx.compose.remote.creation.compose.modifier.onTouchDown
import androidx.compose.remote.creation.compose.modifier.onTouchUp
import androidx.compose.runtime.Composable

/**
 * Whether the current creation [Profile] supports themed (Android system) colors created with
 * [createThemedRemoteColor].
 *
 * Some profiles, such as `androidx.glance.wear.GlanceWearProfiles.wearWidgets`, do not include the
 * color theme operation. Design systems and components can check this before emitting themed colors
 * and fall back to named or literal colors when it is `false`.
 */
@Composable
@RemoteComposable
public fun currentProfileSupportsThemedColors(): Boolean = currentProfileSupports(OP_COLOR_THEME)

/**
 * Whether the current creation [Profile] supports the touch down, up and cancel modifiers
 * ([onTouchDown], [onTouchUp], [onTouchCancel]), for example to drive a press animation.
 *
 * Some profiles, such as `androidx.glance.wear.GlanceWearProfiles.wearWidgets`, do not include
 * those touch operations.
 */
@Composable
@RemoteComposable
public fun currentProfileSupportsTouchModifiers(): Boolean =
    currentProfileSupports(
        OP_MODIFIER_TOUCH_DOWN,
        OP_MODIFIER_TOUCH_UP,
        OP_MODIFIER_TOUCH_CANCEL,
    )

/**
 * Whether the current creation [Profile] supports all of the given [operations].
 *
 * Prefer specific capability helpers such as [currentProfileSupportsThemedColors] or
 * [currentProfileSupportsTouchModifiers] when available. Operation IDs are not public API so must
 * be known ahead of time. Use with care.
 */
@Composable
@RemoteComposable
public fun currentProfileSupports(vararg operations: Int): Boolean {
    val supportedOperations = LocalRemoteComposeCreationState.current.supportedOperations
    return operations.all { it in supportedOperations }
}

// Port: commonMain cannot read the Java `androidx.compose.remote.core.Operations`, so the operation
// ids are spelled here (they are wire-format constants). The port's creation state carries the
// profile's operations as `supportedOperations`; a capture without a profile (the JVM/Wasm
// clients) has none, so it reports no themed colors and no touch modifiers.
private const val OP_COLOR_THEME = 196
private const val OP_MODIFIER_TOUCH_DOWN = 219
private const val OP_MODIFIER_TOUCH_UP = 220
private const val OP_MODIFIER_TOUCH_CANCEL = 225
